//
//  RBCheckViewController.h
//  Content Jokes
//
//  Created by qianfeng on 15-1-23.
//  Copyright (c) 2015年 Riber. All rights reserved.
//

#import "RBBaseViewController.h"

@interface RBCheckViewController : RBBaseViewController

//- (IBAction)weChatLogin:(id)sender;
//- (IBAction)qqLogin:(id)sender;
//- (IBAction)sinaLogin:(id)sender;
//- (IBAction)tencentWeiboLogin:(id)sender;
//- (IBAction)renrenLogin:(id)sender;
//- (IBAction)kaixinNetLogin:(id)sender;

- (IBAction)checkboxClick:(UIButton *)sender;

@end
