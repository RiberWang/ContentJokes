//
//  RBDBManager.h
//  Content Jokes
//
//  Created by Riber on 15/4/16.
//  Copyright (c) 2015年 Riber. All rights reserved.
//

#import <Foundation/Foundation.h>
@class RBContentModel;

@interface RBDBManager : NSObject

+ (id)defalutDBManager;
- (BOOL)createSQLTable;
- (void)createBackUpSQLTable;
- (void)deleteAllSQLTable;
- (void)insertModel:(RBContentModel *)model;
- (void)deleteModel:(RBContentModel *)model;
- (NSArray *)selectContentJokes;

@end
