//
//  RBDetailModel.m
//  Content Jokes
//
//  Created by qianfeng on 15-1-25.
//  Copyright (c) 2015年 Riber. All rights reserved.
//

#import "RBDetailModel.h"

@implementation RBDetailModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}

@end
