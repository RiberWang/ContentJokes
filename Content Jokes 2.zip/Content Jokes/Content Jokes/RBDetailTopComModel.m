//
//  RBDetailTopComModel.m
//  Content Jokes
//
//  Created by qianfeng on 15-1-31.
//  Copyright (c) 2015年 Riber. All rights reserved.
//

#import "RBDetailTopComModel.h"

@implementation RBDetailTopComModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}

@end
