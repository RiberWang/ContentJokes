//
//  RBImageDetailViewController.h
//  Content Jokes
//
//  Created by qianfeng on 15-1-31.
//  Copyright (c) 2015年 Riber. All rights reserved.
//

#import "RBDetailViewController.h"

@interface RBImageDetailViewController : RBDetailViewController

@property(nonatomic, strong) RBImageModel *imageModel;//接收点击的图片段子的数据

@end
