//
//  RBJokeCell.h
//  Content Jokes
//
//  Created by qianfeng on 15-1-24.
//  Copyright (c) 2015年 Riber. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIImageView+WebCache.h"

@interface RBJokeCell : UITableViewCell

@end
