//
//  RBQuestionViewController.h
//  Content Jokes
//
//  Created by qianfeng on 15-1-29.
//  Copyright (c) 2015年 Riber. All rights reserved.
//

#import "RBBaseViewController.h"

@interface RBQuestionViewController : RBBaseViewController

@property(nonatomic, strong) id delegate;

@end
