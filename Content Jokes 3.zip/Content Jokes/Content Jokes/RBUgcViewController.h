//
//  RBUgcViewController.h
//  Content Jokes
//
//  Created by qianfeng on 15-2-2.
//  Copyright (c) 2015年 Riber. All rights reserved.
//

#import "RBUGCSuperVC.h"

//投稿页
@interface RBUgcViewController : RBUGCSuperVC

@property(nonatomic, copy) NSString *userId;

@end
