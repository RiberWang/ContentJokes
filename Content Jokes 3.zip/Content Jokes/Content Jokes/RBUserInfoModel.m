//
//  RBUserInfoModel.m
//  Content Jokes
//
//  Created by qianfeng on 15-1-28.
//  Copyright (c) 2015年 Riber. All rights reserved.
//

#import "RBUserInfoModel.h"

@implementation RBUserInfoModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}

@end
