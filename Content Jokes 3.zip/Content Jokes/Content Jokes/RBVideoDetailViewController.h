//
//  RBVideoDetailViewController.h
//  Content Jokes
//
//  Created by qianfeng on 15-2-1.
//  Copyright (c) 2015年 Riber. All rights reserved.
//

#import "RBDetailViewController.h"

@interface RBVideoDetailViewController : RBDetailViewController

@property(nonatomic, strong) RBVideoModel *videoModel;//接收点击的视频段子的数据

@end
