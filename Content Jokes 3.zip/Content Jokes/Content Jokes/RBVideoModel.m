//
//  RBVideoModel.m
//  Content Jokes
//
//  Created by qianfeng on 15-1-26.
//  Copyright (c) 2015年 Riber. All rights reserved.
//

#import "RBVideoModel.h"

@implementation RBVideoModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}

@end
