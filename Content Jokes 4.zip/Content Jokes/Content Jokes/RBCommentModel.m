//
//  RBCommentModel.m
//  Content Jokes
//
//  Created by qianfeng on 15-3-3.
//  Copyright (c) 2015年 Riber. All rights reserved.
//

#import "RBCommentModel.h"

@implementation RBCommentModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}

@end
