//
//  RBFindDetailViewController.h
//  Content Jokes
//
//  Created by qianfeng on 15-3-5.
//  Copyright (c) 2015年 Riber. All rights reserved.
//

#import "RBImageViewController.h"

@class RBFindModel;

@interface RBFindDetailViewController : RBBaseTableViewController

@property(nonatomic, strong) RBFindModel *findModel; // 接收头部视图的数据

@end
