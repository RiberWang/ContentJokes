//
//  RBCommentViewController.h
//  Content Jokes
//
//  Created by qianfeng on 15-2-3.
//  Copyright (c) 2015年 Riber. All rights reserved.
//

#import "RBBaseTableViewController.h"

@interface RBCommentViewController : RBBaseTableViewController

@property(nonatomic, copy) NSString *userId;

@end
