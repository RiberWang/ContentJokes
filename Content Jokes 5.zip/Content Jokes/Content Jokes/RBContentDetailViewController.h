//
//  RBContentDetailViewController.h
//  Content Jokes
//
//  Created by qianfeng on 15-1-31.
//  Copyright (c) 2015年 Riber. All rights reserved.
//

#import "RBDetailViewController.h"

@interface RBContentDetailViewController : RBDetailViewController

@property(nonatomic, strong) RBContentModel *contentModel;//接收点击的文字段子的数据

@end
