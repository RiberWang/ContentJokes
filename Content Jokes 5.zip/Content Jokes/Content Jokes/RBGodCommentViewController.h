//
//  RBGodCommentViewController.h
//  Content Jokes
//
//  Created by qianfeng on 15-3-5.
//  Copyright (c) 2015年 Riber. All rights reserved.
//

#import "RBCommentViewController.h"

@interface RBGodCommentViewController : RBCommentViewController

@end
