//
//  RBImageViewController.h
//  Content Jokes
//
//  Created by qianfeng on 15-1-23.
//  Copyright (c) 2015年 Riber. All rights reserved.
//

#import "RBBaseTableViewController.h"

@interface RBImageViewController : RBBaseTableViewController

@end
