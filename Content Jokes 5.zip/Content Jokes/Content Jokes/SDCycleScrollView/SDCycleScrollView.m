#import "SDCycleScrollView.h"
#import "SDCollectionViewCell.h"
#import "UIView+SDExtension.h"
#import "TAPageControl.h"
#import "NSData+SDDataCache.h"

NSString *const ID = @"cycleCell";

@interface SDCycleScrollView () <UICollectionViewDataSource, UICollectionViewDelegate>
@property(nonatomic, strong) NSMutableArray *imagesGroup;
@property(nonatomic, weak) UICollectionView *mainView; // 显示图片的collectionView
@property(nonatomic, weak) UICollectionViewFlowLayout *flowLayout;
@property(nonatomic, strong) NSTimer *timer;
@property(nonatomic, assign) NSInteger totalItemsCount;
@property(nonatomic, weak) TAPageControl *pageControl;
@end

@implementation SDCycleScrollView {
    NSMutableArray *_imagesGroup;
}


- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.pageControlAliment = SDCycleScrollViewPageContolAlimentCenter;
        _autoScrollTimeInterval = 1.0;
        [self setupMainView];
    }
    return self;
}


#pragma mark 组件入口  LocalImage

+ (instancetype)cycleScrollViewWithFrame:(CGRect)frame imagesGroup:(NSArray *)imagesGroup {
    SDCycleScrollView *cycleScrollView = [[self alloc] initWithFrame:frame];
    cycleScrollView.imagesGroup = [NSMutableArray arrayWithArray:imagesGroup];
    return cycleScrollView;
}

#pragma mark 组件入口  URLImage

+ (instancetype)cycleScrollViewWithFrame:(CGRect)frame imageURLsGroup:(NSArray *)imageURLsGroup {
    //SDCycleScrollView 继承与View
    SDCycleScrollView *cycleScrollView = [[self alloc] initWithFrame:frame];
    cycleScrollView.imageURLsGroup = imageURLsGroup;
    return cycleScrollView;
}

- (void)setFrame:(CGRect)frame {
    [super setFrame:frame];
    _flowLayout.itemSize = self.frame.size;
}

//autoScrollTimeInterval 滚动图片数
- (void)setAutoScrollTimeInterval:(CGFloat)autoScrollTimeInterval {
    _autoScrollTimeInterval = autoScrollTimeInterval;
    [_timer invalidate];
    _timer = nil;
    [self setupTimer];
}

#pragma mark  设置显示图片的collectionView

- (void)setupMainView {
    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
    flowLayout.itemSize = self.frame.size;
    flowLayout.minimumLineSpacing = 0;
    flowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    _flowLayout = flowLayout;

    UICollectionView *mainView = [[UICollectionView alloc] initWithFrame:self.frame collectionViewLayout:flowLayout];
    mainView.backgroundColor = [UIColor lightGrayColor];
    mainView.pagingEnabled = YES;
    mainView.showsHorizontalScrollIndicator = NO;
    mainView.showsVerticalScrollIndicator = NO;
    [mainView registerClass:[SDCollectionViewCell class] forCellWithReuseIdentifier:ID];
    mainView.dataSource = self;
    mainView.delegate = self;
    [self addSubview:mainView];
    _mainView = mainView;
}

- (void)setImagesGroup:(NSMutableArray *)imagesGroup {
    _imagesGroup = imagesGroup;
    _totalItemsCount = imagesGroup.count * 100;

    [self setupTimer];
    [self setupPageControl];
}

#pragma mark  给图片赋值时会执行

- (void)setImageURLsGroup:(NSArray *)imageURLsGroup {
    _imageURLsGroup = imageURLsGroup;
    NSMutableArray *images = [NSMutableArray arrayWithCapacity:imageURLsGroup.count];
    for (int i = 0; i < imageURLsGroup.count; i++) {
        UIImage *image = [[UIImage alloc] init];
        [images addObject:image];
    }
    self.imagesGroup = images;   //空的Image
    [self loadImageWithImageURLsGroup:imageURLsGroup];  //加载URL图片
    [self.mainView reloadData];
}

- (void)loadImageWithImageURLsGroup:(NSArray *)imageURLsGroup {
    for (int i = 0; i < imageURLsGroup.count; i++) {
        [self loadImageAtIndex:i];
    }
}

- (void)loadImageAtIndex:(NSUInteger)index {
    NSURL *url = self.imageURLsGroup[index];
    // 如果有缓存，直接加载缓存
    NSData *nsdata = [NSData getDataCacheWithIdentifier:url.absoluteString];
    if (nsdata) {
        self.imagesGroup[index] = [UIImage imageWithData:nsdata];
    } else {
        [NSURLConnection sendAsynchronousRequest:[NSURLRequest requestWithURL:url] queue:[[NSOperationQueue alloc] init] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
            if (!connectionError) {
                self.imagesGroup[index] = [UIImage imageWithData:data];
                [data saveDataCacheWithIdentifier:url.absoluteString];
            } else { // 加载数据失败
                static int repeat = 0;
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t) (2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    if (repeat > 10) return;
                    [self loadImageAtIndex:index]; //循环调用十次
                    repeat++;
                });

            }
        }
        ];
    }
}


- (void)setupPageControl {
    if (_pageControl) [_pageControl removeFromSuperview]; // 重新加载数据时调整
    TAPageControl *pageControl = [[TAPageControl alloc] init];
    pageControl.numberOfPages = self.imagesGroup.count;
    [self addSubview:pageControl];
    _pageControl = pageControl;
}

#pragma mark 切换图片设置

- (void)automaticScroll {
    if (0 == _totalItemsCount) return;
    int currentIndex = (int) (_mainView.contentOffset.x / _flowLayout.itemSize.width);
    int targetIndex = currentIndex + 1;
    if (targetIndex == _totalItemsCount) {
        targetIndex = (int) (_totalItemsCount * 0.5);
        [_mainView scrollToItemAtIndexPath:[NSIndexPath indexPathForItem:targetIndex inSection:0] atScrollPosition:UICollectionViewScrollPositionNone animated:NO];
    }
    [_mainView scrollToItemAtIndexPath:[NSIndexPath indexPathForItem:targetIndex inSection:0] atScrollPosition:UICollectionViewScrollPositionNone animated:YES];
}

- (void)setupTimer {
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:self.autoScrollTimeInterval target:self selector:@selector(automaticScroll) userInfo:nil repeats:YES];
    _timer = timer;
    [[NSRunLoop mainRunLoop] addTimer:timer forMode:NSRunLoopCommonModes];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    _mainView.frame = self.bounds;
    if (_mainView.contentOffset.x == 0 && _totalItemsCount) {
        [_mainView scrollToItemAtIndexPath:[NSIndexPath indexPathForItem:_totalItemsCount * 0.5 inSection:0] atScrollPosition:UICollectionViewScrollPositionNone animated:NO];
    }

    CGSize size = [_pageControl sizeForNumberOfPages:self.imagesGroup.count];
    CGFloat x = (CGFloat) ((self.sd_width - size.width) * 0.5);
    if (self.pageControlAliment == SDCycleScrollViewPageContolAlimentRight) {
        x = self.mainView.sd_width - size.width - 10;
    }
    CGFloat y = self.mainView.sd_height - size.height - 10;
    _pageControl.frame = CGRectMake(x, y, size.width, size.height);
    [_pageControl sizeToFit];
}


#pragma mark - UICollectionViewDataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return _totalItemsCount;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    SDCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:ID forIndexPath:indexPath];
    NSUInteger itemIndex = (indexPath.item % self.imagesGroup.count);
    cell.imageView.image = self.imagesGroup[itemIndex];
    if (_titlesGroup.count) {
        cell.title = _titlesGroup[itemIndex];
    }
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    if ([self.delegate respondsToSelector:@selector(cycleScrollView:didSelectItemAtIndex:)]) {
        [self.delegate cycleScrollView:self didSelectItemAtIndex:indexPath.item % self.imagesGroup.count];
    }
}

//解决当父View释放时，当前视图因为被Timer强引用而不能释放的问题
- (void)willMoveToSuperview:(UIView *)newSuperview {
    if (!newSuperview) {
        [_timer invalidate];
        _timer = nil;
    }
}

#pragma mark - UIScrollViewDelegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    int itemIndex = (int) ((scrollView.contentOffset.x + self.mainView.sd_width * 0.5) / self.mainView.sd_width);
    int indexOnPageControl = itemIndex % self.imagesGroup.count;
    _pageControl.currentPage = indexOnPageControl;
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    [_timer invalidate];
    _timer = nil;
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    [self setupTimer];
}
@end
