//
//  LeftViewController.h
//  Content Jokes
//
//  Created by riber on 15/12/7.
//  Copyright © 2015年 Riber. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RBBaseViewController.h"

@interface LeftViewController : RBBaseViewController

@end
