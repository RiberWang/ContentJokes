//
//  RBFindDetailSecond.h
//  Content Jokes
//
//  Created by riber on 15/12/15.
//  Copyright (c) 2015年 Riber. All rights reserved.
//

#import "RBImageDetailViewController.h"

@interface RBFindDetailSecond : RBImageDetailViewController

@end
