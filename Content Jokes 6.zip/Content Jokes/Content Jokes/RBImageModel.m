//
//  RBImageModel.m
//  Content Jokes
//
//  Created by qianfeng on 15-1-24.
//  Copyright (c) 2015年 Riber. All rights reserved.
//

#import "RBImageModel.h"

@implementation RBImageModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}

@end
