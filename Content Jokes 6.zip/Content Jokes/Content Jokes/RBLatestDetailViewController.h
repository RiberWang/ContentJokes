//
//  RBLatestDetailViewController.h
//  Content Jokes
//
//  Created by qianfeng on 15-3-1.
//  Copyright (c) 2015年 Riber. All rights reserved.
//

#import "RBContentDetailViewController.h"

@interface RBLatestDetailViewController : RBContentDetailViewController

@end
