//
//  RBLatestModel.m
//  Content Jokes
//
//  Created by qianfeng on 15-3-1.
//  Copyright (c) 2015年 Riber. All rights reserved.
//

#import "RBLatestModel.h"

@implementation RBLatestModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}

//- (NSString *)description {
//    return [NSString stringWithFormat:self.url, self.name];
//}

@end
