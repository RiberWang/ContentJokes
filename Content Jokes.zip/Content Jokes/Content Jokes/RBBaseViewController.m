//
//  RBBaseViewController.m
//  Content Jokes
//
//  Created by qianfeng on 15-1-23.
//  Copyright (c) 2015年 Riber. All rights reserved.
//

#import "RBBaseViewController.h"
#import "RBUserInfoViewController.h"

@interface RBBaseViewController ()

@end

@implementation RBBaseViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self createNavBarItem];
}

- (void)createNavBarItem {
    self.view.backgroundColor = RGB(234, 234, 234);
    
    //创建导航上的用户头像 左侧按钮
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, 0, 30, 30);
    [leftBtn setImage:[UIImage imageNamed:@"defaulthead.png"] forState:UIControlStateNormal];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:leftBtn];
    
    //使用户头像按钮的点击的范围变小
    UIButton *leftSpaceBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftSpaceBtn.frame = CGRectMake(0, 0, 30, 30);
    UIBarButtonItem *leftSpaceItem = [[UIBarButtonItem alloc] initWithCustomView:leftSpaceBtn];
    self.navigationItem.leftBarButtonItems = @[leftItem, leftSpaceItem];
}

@end
