//
//  RBContentCell.m
//  Content Jokes
//
//  Created by qianfeng on 15-1-23.
//  Copyright (c) 2015年 Riber. All rights reserved.
//

#import "RBContentCell.h"
#import "RBContentModel.h"
#import "RBImageModel.h"

@implementation RBContentCell

- (void)awakeFromNib
{
    // Initialization code
    self.avatarImage.layer.masksToBounds = YES;
    self.avatarImage.layer.cornerRadius = 15;
    self.statusImage.hidden = YES;
    
    // 使用label添加下划线
//    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 20-1, 80, 1)];
//    label.backgroundColor = [UIColor redColor];
//    [self.titleButton addSubview:label];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

// 显示内容段子
- (void)showInContentCell:(RBContentModel *)contentModel {
    [self.avatarImage setImageWithURL:[NSURL URLWithString:contentModel.avatar_url]];
    self.contentImage.hidden = YES;
    self.nameLabel.text = contentModel.name;
    self.contentLabel.text = contentModel.content;
    self.diggCountLabel.text = [NSString stringWithFormat:@"%@", contentModel.digg_count];
    self.buryCountLabel.text = [NSString stringWithFormat:@"%@", contentModel.bury_count];
    self.commentCountLabel.text = [NSString stringWithFormat:@"%@", contentModel.comment_count];
}

// 显示图片段子
- (void)showInImageCell:(RBImageModel *)imageModel {
    [self.avatarImage setImageWithURL:[NSURL URLWithString:imageModel.avatar_url]];
    self.nameLabel.text = imageModel.name;

    if (imageModel.url != nil) {
        [self.contentImage setImageWithURL:[NSURL URLWithString:imageModel.url]];
    } else {
        self.contentImage.hidden = YES;
    }
    if (imageModel.content.length != 0) {
        self.contentLabel.text = imageModel.content;
    } else {
        self.contentLabel.hidden = YES;
    }

    self.diggCountLabel.text = [NSString stringWithFormat:@"%@", imageModel.digg_count];
    self.buryCountLabel.text = [NSString stringWithFormat:@"%@", imageModel.bury_count];
    self.commentCountLabel.text = [NSString stringWithFormat:@"%@", imageModel.comment_count];
}

- (void)nonClickBtn:(id)sender {
    
}

@end
