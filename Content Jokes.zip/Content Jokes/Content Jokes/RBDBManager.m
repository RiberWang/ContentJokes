//
//  RBDBManager.m
//  Content Jokes
//
//  Created by Riber on 15/4/16.
//  Copyright (c) 2015年 Riber. All rights reserved.
//

#import "RBDBManager.h"
#import "FMDatabase.h"

#define DBNAME @"ContentJokes.db"
#define DBNAME_COPY @"ContentJokesBak.db"

@implementation RBDBManager {
    FMDatabase *fmdbManager;
}

static RBDBManager *manager = nil;
static dispatch_once_t predicate;

+ (id)defalutDBManager {
    // 保证线程安全
   dispatch_once(&predicate, ^{
       if (manager == nil) {
           manager = [[self alloc] init];
       }
   });
    return manager;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    dispatch_once(&predicate, ^{
        if (manager == nil) {
            manager = [super allocWithZone:zone];
        }
    });
    return manager;
}

/*
    第二种方式获取沙盒路径
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *path1 = [[paths objectAtIndex:0] stringByAppendingPathComponent:DBNAME];
 */
// 创建数据库表
- (BOOL)createSQLTable {
    // 1.获取数据库存储的路径(沙盒路径)
    NSString *path = [NSHomeDirectory() stringByAppendingString:[NSString stringWithFormat:@"/Documents/%@", DBNAME]];
    // 2.初始化fmdbManager
    fmdbManager = [[FMDatabase alloc] initWithPath:path];
    // 3.打开数据库
    BOOL isOpen = [fmdbManager open];
    if (!isOpen) {
        return NO;
    }
    
    /*
     @property(nonatomic, copy) NSString *avatar_url;//头像
     @property(nonatomic, copy) NSString *name;//名称
     @property(nonatomic, strong) NSNumber *user_id;//用户id
     @property(nonatomic, strong) NSNumber *group_id;//点击段子的id
     @property(nonatomic, copy) NSString *content;//发表内容
     @property(nonatomic, strong) NSNumber *digg_count;//顶的个数
     @property(nonatomic, strong) NSNumber *bury_count;//踩的个数
     @property(nonatomic, strong) NSNumber *comment_count;//评论个数
     */
    
    // 4.创建表
    NSString *sql = @"create table if not exists Jokes(ID integer primary key autoincrement, name varchar(256), avatar blob, userid integer, groupid integer, content varchar(1024), contentimage blob, digcount integer, burycount integer)";
    if (isOpen && [fmdbManager executeUpdate:sql]) {
        return YES;
    }
    
    return NO;
}

// 数据库备份
- (void)createBackUpSQLTable {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *path = [paths[0] stringByAppendingPathComponent:DBNAME];
    NSString *pathBak = [paths[0] stringByAppendingFormat:DBNAME_COPY];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    if ([fileManager fileExistsAtPath:pathBak]) {
        [fileManager removeItemAtPath:pathBak error:nil];
    }
    [fileManager copyItemAtPath:path toPath:pathBak error:nil];
}

// 删除数据库
- (void)deleteAllSQLTable {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
    NSString *path = [paths[0] stringByAppendingPathComponent:DBNAME];
    NSString *pathBak = [paths[0] stringByAppendingPathComponent:DBNAME];

    NSFileManager *fileManager = [NSFileManager defaultManager];
    if ([fileManager fileExistsAtPath:path]) {
        [fileManager removeItemAtPath:path error:nil];
        [fileManager removeItemAtPath:pathBak error:nil];
    }
}

// 向数据库表中插入数据

@end
