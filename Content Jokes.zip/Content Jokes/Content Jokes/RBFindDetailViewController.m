//
//  RBFindDetailViewController.m
//  Content Jokes
//
//  Created by qianfeng on 15-3-5.
//  Copyright (c) 2015年 Riber. All rights reserved.
//

#import "RBFindDetailViewController.h"
#import "RBFindModel.h"
#import "RBFindDetailTableViewHeaderView.h"

@interface RBFindDetailViewController ()

@end

@implementation RBFindDetailViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        self.hidesBottomBarWhenPushed = YES;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //返回按钮
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(0, 0, 40, 44);
    [btn setImage:[UIImage imageNamed:@"leftBackButtonFGNormal.png"] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(leftBackButton:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithCustomView:btn];
    self.navigationItem.leftBarButtonItem = item;
    
    //1425529334
    self.url = [NSString stringWithFormat:FIND_PATH_DETAIL, _findModel.categoryId, FIND_PATH_DETAIL_PART1, 1425529334, FIND_PATH_DETAIL_PART2];
    [self startRequest];
    
}

#pragma mark - 修改刷新按钮的位置 这个页面的tabBar隐藏了
- (void)createRefreshBtn {
    [super createRefreshBtn];
    self.refreshBtn.frame = CGRectMake(WINDOW_SIZE.width-60,WINDOW_SIZE.height-64-60, 40, 40);
}

- (void)createUI {
    self.dataSources = [[NSMutableArray alloc] init];
    self.edgesForExtendedLayout = UIRectEdgeNone;
    
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, WINDOW_SIZE.width, WINDOW_SIZE.height - 64) style:UITableViewStyleGrouped]; // grouped样式的表格的尾部会出现一片空白 解决办法:设置表格的高度时 在算好的高度上+36(大概的数值) 下面有刷新的视图 这样设置不行
    self.tableView.backgroundColor = RGB(234, 234, 234);
    self.tableView.rowHeight = 50;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
}

- (void)leftBackButton:(UIButton *)button {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)setUrl {
    int min_time = [[NSDate date] timeIntervalSince1970];
    self.url = [NSString stringWithFormat:FIND_PATH_DETAIL, _findModel.categoryId, FIND_PATH_DETAIL_PART1, min_time, FIND_PATH_DETAIL_PART2];
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    RBFindDetailTableViewHeaderView *headerView = [RBFindDetailTableViewHeaderView findDetailTableViewHeaderView];
    
    // 填充数据
    [headerView.iconImgView setImageWithURL:[NSURL URLWithString:_findModel.icon]];
    headerView.nameLabel.text = _findModel.name;
    headerView.placeholderLabel.text = _findModel.placeholder;
    
    return headerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        return 80;
    }
    return 0;
}


@end
