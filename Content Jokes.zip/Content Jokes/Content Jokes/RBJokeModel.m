//
//  RBJokeModel.m
//  Content Jokes
//
//  Created by qianfeng on 15-3-4.
//  Copyright (c) 2015年 Riber. All rights reserved.
//

#import "RBJokeModel.h"

@implementation RBJokeModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}

@end
