//
//  RBRepinViewController.h
//  Content Jokes
//
//  Created by qianfeng on 15-3-3.
//  Copyright (c) 2015年 Riber. All rights reserved.
//

#import "RBImageViewController.h"

@interface RBRepinViewController : RBImageViewController

@property(nonatomic, copy) NSString *userId;

@end
